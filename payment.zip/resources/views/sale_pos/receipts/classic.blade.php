<!-- business information here -->

<div class="row">

	<!-- Logo -->
	@if(!empty($receipt_details->logo))
		<img src="{{$receipt_details->logo}}" class="img img-responsive center-block">
	@endif

	<!-- Header text -->
	@if(!empty($receipt_details->header_text))
		<div class="col-xs-12">
			{!! $receipt_details->header_text !!}
		</div>
	@endif

	<!-- business information here -->
	<div class="col-xs-12 text-center">
		<h2 class="text-center">
			<!-- Shop & Location Name  -->

			@if(!empty($receipt_details->display_name))
				<img src="{{asset('/img'.'/' . \DB::table("logo")->where('id','1')->first()->name)}}" class="img img-responsive center-block" style="height:15rem;width:15rem;" >
			@endif
		</h2>

		<!-- Address -->
		<p>
		@if(!empty($receipt_details->address))
				<small class="text-center">
				{!! $receipt_details->address !!}
				</small>
		@endif

		@if(!empty($receipt_details->contact))
			<br/>{{ $receipt_details->contact }}
		@endif
		@if(!empty($receipt_details->contact) && !empty($receipt_details->website))
			,
		@endif
		@if(!empty($receipt_details->website))
			{{ $receipt_details->website }}
		@endif
		@if(!empty($receipt_details->location_custom_fields))
			<br>{{ $receipt_details->location_custom_fields }}
		@endif
		</p>
		<p>
		@if(!empty($receipt_details->sub_heading_line1))
			{{ $receipt_details->sub_heading_line1 }}
		@endif
		@if(!empty($receipt_details->sub_heading_line2))
			<br>{{ $receipt_details->sub_heading_line2 }}
		@endif
		@if(!empty($receipt_details->sub_heading_line3))
			<br>{{ $receipt_details->sub_heading_line3 }}
		@endif
		@if(!empty($receipt_details->sub_heading_line4))
			<br>{{ $receipt_details->sub_heading_line4 }}
		@endif
		@if(!empty($receipt_details->sub_heading_line5))
			<br>{{ $receipt_details->sub_heading_line5 }}
		@endif
		</p>
		<p>
		@if(!empty($receipt_details->tax_info1))
			<b>{{ $receipt_details->tax_label1 }}</b> {{ $receipt_details->tax_info1 }}
		@endif

		@if(!empty($receipt_details->tax_info2))
			<b>{{ $receipt_details->tax_label2 }}</b> {{ $receipt_details->tax_info2 }}
		@endif
		</p>

		<!-- Title of receipt -->
		@if(!empty($receipt_details->invoice_heading))
			<h3 class="text-center">
				{!! $receipt_details->invoice_heading !!}
			</h3>
		@endif

		<!-- Invoice  number, Date  -->
		<p style="width: 100% !important" class="word-wrap">
			<span class="pull-left text-left word-wrap">
				@if(!empty($receipt_details->invoice_no_prefix))
					<b>{!! $receipt_details->invoice_no_prefix !!}</b>
				@endif
				{{$receipt_details->invoice_no}}

				<!-- Table information-->
		        @if(!empty($receipt_details->table_label) || !empty($receipt_details->table))
		        	<br/>
					<span class="pull-left text-left">
						@if(!empty($receipt_details->table_label))
							<b>{!! $receipt_details->table_label !!}</b>
						@endif
						{{$receipt_details->table}}

						<!-- Waiter info -->
					</span>
		        @endif

				<!-- customer info -->
				@if(!empty($receipt_details->customer_info))
					<br/>
					<b>{{ $receipt_details->customer_label }}</b> {!! $receipt_details->customer_info !!}
				@endif
				@if(!empty($receipt_details->client_id_label))
					<br/>
					<b>{{ $receipt_details->client_id_label }}</b> {{ $receipt_details->client_id }}
				@endif
				@if(!empty($receipt_details->customer_tax_label))
					<br/>
					<b>{{ $receipt_details->customer_tax_label }}</b> {{ $receipt_details->customer_tax_number }}
				@endif
				@if(!empty($receipt_details->customer_custom_fields))
					<br/>{!! $receipt_details->customer_custom_fields !!}
				@endif
				@if(!empty($receipt_details->sales_person_label))
					<br/>
					<b>{{ $receipt_details->sales_person_label }}</b> {{ $receipt_details->sales_person }}
				@endif
				@if(!empty($receipt_details->doctor))
				<br/>
				<b>doctor</b> {{ $receipt_details->doctor->name }}
			@endif
			@if(!empty($receipt_details->assistant))
				<br/>
				<b>assistant</b> {{ $receipt_details->assistant->name }}
			@endif
			</span>

			<span class="pull-right">
				<b>{{$receipt_details->date_label}}</b> {{$receipt_details->invoice_date}}

				<!-- Waiter info -->
				@if(!empty($receipt_details->service_staff_label) || !empty($receipt_details->service_staff))
		        	<br/>
					@if(!empty($receipt_details->service_staff_label))
						<b>{!! $receipt_details->service_staff_label !!}</b>
					@endif
					{{$receipt_details->service_staff}}
		        @endif
			</span>
		</p>
	</div>
	<!-- /.col -->
</div>


<div class="row">
	<div class="col-xs-12">
		<br/><br/>
		{{-- product --}}
		<table class="table table-responsive">
			<thead>
				<tr>
					<th>{{$receipt_details->table_product_label}}</th>
					<th>{{$receipt_details->table_qty_label}}</th>

					<th>{{$receipt_details->table_unit_price_label}}</th>
					<th>{{$receipt_details->table_subtotal_label}}</th>

				</tr>
			</thead>
			<tbody>
				@forelse($receipt_details->lines as $line)
				 @if ($line["category_id"] != "30")
						<tr>
						<td style="word-break: break-all;">
                            {{$line['name']}} {{$line['variation']}}
                            @if(!empty($line['sub_sku'])), {{$line['sub_sku']}} @endif @if(!empty($line['brand'])), {{$line['brand']}} @endif @if(!empty($line['cat_code'])), {{$line['cat_code']}}@endif
                            @if(!empty($line['sell_line_note']))({{$line['sell_line_note']}}) @endif
                            @if(!empty($line['lot_number']))<br> {{$line['lot_number_label']}}:  {{$line['lot_number']}} @endif
                            @if(!empty($line['product_expiry'])), {{$line['product_expiry_label']}}:  {{$line['product_expiry']}} @endif
                        </td>
						<td>{{$line['quantity']}} {{$line['units']}} </td>

						<td>{{$line['unit_price_inc_tax']}}</td>
						<td>{{$line['line_total']}}</td>

					</tr>
				@endif 
				
				@empty
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				@endforelse
			</tbody>
		</table>
		{{-- doctor --}}	
		
		<h3 class="text-center">
		Doctor
		</h3>
		<hr>
		<table class="table table-responsive">
			<thead>
				<tr>
					<th>{{$receipt_details->table_product_label}}</th>
					<th>{{$receipt_details->table_qty_label}}</th>

					<th>{{$receipt_details->table_unit_price_label}}</th>
					<th>{{$receipt_details->table_subtotal_label}}</th>

				</tr>
			</thead>
			<tbody>
				@forelse($receipt_details->lines as $line)
				@if ($line["category_id"] == "30" && !empty($line["doctor_id"]))
					   <tr>
					   <td style="word-break: break-all;">
						   {{$line['name']}} {{$line['variation']}}
						   @if(!empty($line['sub_sku'])), {{$line['sub_sku']}} @endif @if(!empty($line['brand'])), {{$line['brand']}} @endif @if(!empty($line['cat_code'])), {{$line['cat_code']}}@endif
						   @if(!empty($line['sell_line_note']))({{$line['sell_line_note']}}) @endif
						   @if(!empty($line['lot_number']))<br> {{$line['lot_number_label']}}:  {{$line['lot_number']}} @endif
						   @if(!empty($line['product_expiry'])), {{$line['product_expiry_label']}}:  {{$line['product_expiry']}} @endif
					   </td>
					   <td>{{$line['quantity']}} {{$line['units']}} </td>

					   <td>{{$line['unit_price_inc_tax']}}</td>
					   <td>{{$line['line_total']}}</td>

				   </tr>
			   @endif 
			   
			   @empty
				   <tr>
					   <td colspan="4">&nbsp;</td>
				   </tr>
			   @endforelse
			</tbody>
		</table>
		{{-- assistant --}}
		<h3 class="text-center">
			Assistant
			</h3>
			<hr>
		<table class="table table-responsive">
			<thead>
				<tr>
					<th>{{$receipt_details->table_product_label}}</th>
					<th>{{$receipt_details->table_qty_label}}</th>

					<th>{{$receipt_details->table_unit_price_label}}</th>
					<th>{{$receipt_details->table_subtotal_label}}</th>

				</tr>
			</thead>
			<tbody>
				@forelse($receipt_details->lines as $line)
				@if ($line["category_id"] == "30" && !empty($line["assistant_id"]))
					   <tr>
					   <td style="word-break: break-all;">
						   {{$line['name']}} {{$line['variation']}}
						   @if(!empty($line['sub_sku'])), {{$line['sub_sku']}} @endif @if(!empty($line['brand'])), {{$line['brand']}} @endif @if(!empty($line['cat_code'])), {{$line['cat_code']}}@endif
						   @if(!empty($line['sell_line_note']))({{$line['sell_line_note']}}) @endif
						   @if(!empty($line['lot_number']))<br> {{$line['lot_number_label']}}:  {{$line['lot_number']}} @endif
						   @if(!empty($line['product_expiry'])), {{$line['product_expiry_label']}}:  {{$line['product_expiry']}} @endif
					   </td>
					   <td>{{$line['quantity']}} {{$line['units']}} </td>

					   <td>{{$line['unit_price_inc_tax']}}</td>
					   <td>{{$line['line_total']}}</td>

				   </tr>
			   @endif 
			   
			   @empty
				   <tr>
					   <td colspan="4">&nbsp;</td>
				   </tr>
			   @endforelse
			</tbody>
		</table>
	</div>
</div>

<div class="row">
	<br/>
	<div class="col-md-12"><hr/></div>
	<br/>


	<div class="col-xs-6">

		<table class="table table-condensed">

			@if(!empty($receipt_details->payments))
				@foreach($receipt_details->payments as $payment)
					<tr>
						<td>{{$payment['method']}}</td>
						<td>{{$payment['amount']}}</td>
						<td>{{$payment['date']}}</td>
					</tr>
				@endforeach
			@endif

			<!-- Total Paid-->
			@if(!empty($receipt_details->total_paid))
				<tr>
					<th>
					&nbsp;
					</th>
					<th>
						{!! $receipt_details->total_paid_label !!}
					</th>
					<td>
						{{$receipt_details->total_paid}}
					</td>
				</tr>
			@endif

			<!-- Total Due-->
			@if(!empty($receipt_details->total_due))
			<tr>
				<th>
					{!! $receipt_details->total_due_label !!}
				</th>
				<td>
					{{$receipt_details->total_due}}
				</td>
			</tr>
			@endif
		</table>

		{{$receipt_details->additional_notes}}
	</div>

	<div class="col-xs-6">
        <div class="table-responsive">
          	<table class="table">
				<tbody>
					<tr>
						<th style="width:70%">
							{!! $receipt_details->subtotal_label !!}
						</th>
						<td>
						        @php

    						        $dis = filter_var($receipt_details->discount, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                                    $line_dis = 0;
                                    if(!empty($receipt_details->line_discount)){
                                        $line_dis = filter_var($receipt_details->line_discount, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                                    }


    						        $toalAmount = filter_var($receipt_details->total, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    						   $subTotal = $toalAmount +$dis + $line_dis;

    						   @endphp
    						    {{-- number_format((float)$subTotal, 2, '.', '')--}}
							{{-- $receipt_details->total --}}

							@if(!empty($receipt_details->discount))
							    {{ number_format((float)$subTotal, 2, '.', '') }}
							    @else
							    {{-- {{ $receipt_details->total }}  --}}
								{{ number_format((float)$subTotal, 2, '.', '') }}
							@endif
						</td>
					</tr>

					<!-- Shipping Charges -->
					@if(!empty($receipt_details->shipping_charges))
						<tr>
							<th style="width:70%">
								{!! $receipt_details->shipping_charges_label !!}
							</th>
							<td>
								{{$receipt_details->shipping_charges}}
							</td>
						</tr>
					@endif

					<!-- Discount -->
					@if( !empty($receipt_details->discount) )
						<tr>
							<th>
								{!! $receipt_details->discount_label !!}
							</th>

							<td>
								(-) {{$receipt_details->discount}}
							</td>
						</tr>
					@endif

						<!-- Line Discount -->
					@if( !empty($receipt_details->line_discount) )
						<tr>
							<th>
							Other Discount
							</th>

							<td>
								(-) {{$receipt_details->line_discount}}
							</td>
						</tr>
					@endif

					<!-- Tax -->
					@if( !empty($receipt_details->tax) )
						<tr>
							<th>
								{!! $receipt_details->tax_label !!}
							</th>
							<td>
								(+) {{$receipt_details->tax}}
							</td>
						</tr>
					@endif

					<!-- Total -->
					<tr>
						<th>
							{!! $receipt_details->total_label !!}
						</th>
						<td>
						    @php
								$dis = filter_var($receipt_details->discount, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
								$toalAmount = filter_var($receipt_details->total, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
								$subTotal = $toalAmount + $dis;

								$totalPay = $subTotal - $dis;
							@endphp
							{{--$receipt_details->total--}}
							{{ number_format((float)$totalPay, 2, '.', '') }}
						</td>
					</tr>
				</tbody>
        	</table>

        </div>
    </div>
</div>
	<div class="row " style="margin-top:5rem;" >
	<div class="col-xs-6"  >

	</div>
	<div class="col-xs-6"  >
	<hr class="signature-line" />
	Authorized Signature
	</div>
</div>

@if($receipt_details->show_barcode)
	<div class="row">
		<div class="col-xs-12">
			{{-- Barcode --}}
			<img class="center-block" src="data:image/png;base64,{{DNS1D::getBarcodePNG($receipt_details->invoice_no, 'C128', 2,30,array(39, 48, 54), true)}}">
		</div>
	</div>
@endif

@if(!empty($receipt_details->footer_text))
	<div class="row">
		<div class="col-xs-12">
			{!! $receipt_details->footer_text !!}
		</div>
	</div>
@endif
<style>
    hr {
    display: block;
    height: 1px;
    background: black;
    width: 100%;
    border: none;
    border-top: solid 1px #aaa;
    margin:0;
}
</style>
