<?php

return [
    'name' => 'Superadmin',
    'module_version' => "0.8.1",
];
