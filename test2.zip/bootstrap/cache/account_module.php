<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Account\\Providers\\AccountServiceProvider',
    1 => 'Modules\\Account\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Account\\Providers\\AccountServiceProvider',
    1 => 'Modules\\Account\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);