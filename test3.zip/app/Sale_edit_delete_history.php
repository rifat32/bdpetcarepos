<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale_edit_delete_history extends Model
{
    protected $table = 'sale_edit_delete_histories';
}
