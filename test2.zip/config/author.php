<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Company/Author/Developer/Licence information of the application
    |--------------------------------------------------------------------------
    |
    | All details about the author/developer/contact/licence of the application
    |
    | IMPORTANT: CHANGING ANY OF THIS INFORMATION WILL UNSTABILIZE THE APPLICATION
    |
    */

    'vendor' => 'Ultimate Fosters',

    'vendor_url' => 'http://ultimatefosters.com',

    'email' => 'thewebfosters@gmail.com',

    'app_version' => "2.11.2",
    'app_envato_personal_token' => 'ftXs1UtOgdtJFYo7ZcHHv46KH3PgLgch',
    'app_envato_username' => 'thewebfosters',
    'app_envato_product_code' => 21216332
];
